<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Core\Database;
use App\Core\Permission;
use App\Models\AuditLog;
use PDO;

class ImportController
{
    private AuditLog $auditLog;

    public function __construct()
    {
        $this->auditLog = new AuditLog();
    }

    // ──────────────────────────────────────────────────────────
    //  GET /importar  — muestra la página principal
    // ──────────────────────────────────────────────────────────
    public function index(): void
    {
        Permission::require('contacts', 'create');
        $tenantName = $_SESSION['tenant_name'] ?? 'Empresa';
        require __DIR__ . '/../../Views/import/index.php';
    }

    // ──────────────────────────────────────────────────────────
    //  POST /importar/preview  — lee el CSV y devuelve JSON
    // ──────────────────────────────────────────────────────────
    public function preview(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        Permission::require('contacts', 'create');

        try {
            if (empty($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
                echo json_encode(['success' => false, 'message' => 'No se recibió ningún archivo CSV.']);
                exit;
            }

            $type   = $_POST['import_type'] ?? 'contacts'; // contacts | accounts
            $tmpPath = $_FILES['csv_file']['tmp_name'];
            $rows    = $this->parseCsv($tmpPath);

            if (empty($rows)) {
                echo json_encode(['success' => false, 'message' => 'El archivo está vacío o no tiene filas válidas.']);
                exit;
            }

            // Validate headers
            $headers = array_keys($rows[0]);
            $required = $type === 'contacts'
                ? ['first_name']
                : ['name'];

            $missing = array_diff($required, $headers);
            if (!empty($missing)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Faltan columnas obligatorias: ' . implode(', ', $missing)
                ]);
                exit;
            }

            // Return preview (max 100 rows shown, full count stored in session)
            $_SESSION['import_pending'] = [
                'type' => $type,
                'rows' => $rows,
            ];

            echo json_encode([
                'success'   => true,
                'type'      => $type,
                'total'     => count($rows),
                'headers'   => $headers,
                'preview'   => array_slice($rows, 0, 10),
            ]);
        } catch (\Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }

    // ──────────────────────────────────────────────────────────
    //  POST /importar/commit  — inserta en la base de datos
    // ──────────────────────────────────────────────────────────
    public function commit(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        Permission::require('contacts', 'create');

        if (empty($_SESSION['import_pending'])) {
            echo json_encode(['success' => false, 'message' => 'No hay datos pendientes. Carga el CSV primero.']);
            exit;
        }

        $pending  = $_SESSION['import_pending'];
        $type     = $pending['type'];
        $rows     = $pending['rows'];
        $tenantId = (int)($_SESSION['tenant_id'] ?? 0);
        $ownerId  = (int)($_SESSION['user_id'] ?? 0);
        $db       = Database::getInstance();

        $inserted = 0;
        $skipped  = 0;
        $errors   = [];

        try {
            $db->beginTransaction();

            if ($type === 'contacts') {
                $sql = "INSERT INTO contacts
                    (tenant_id, owner_id, type, first_name, last_name, email, phone, mobile,
                     job_title, department, linkedin, country, city, postal_code, address, created_at)
                    VALUES
                    (:tenant_id, :owner_id, :type, :first_name, :last_name, :email, :phone, :mobile,
                     :job_title, :department, :linkedin, :country, :city, :postal_code, :address, NOW())
                    ON DUPLICATE KEY UPDATE updated_at = NOW()";

                $stmt = $db->prepare($sql);

                foreach ($rows as $i => $row) {
                    $fn = trim($row['first_name'] ?? '');
                    if ($fn === '') { $skipped++; continue; }

                    try {
                        $stmt->execute([
                            ':tenant_id'  => $tenantId,
                            ':owner_id'   => $ownerId,
                            ':type'       => $this->sanitize($row['type'] ?? 'Prospecto'),
                            ':first_name' => $this->sanitize($fn),
                            ':last_name'  => $this->sanitize($row['last_name'] ?? ''),
                            ':email'      => $this->sanitize($row['email'] ?? ''),
                            ':phone'      => $this->sanitize($row['phone'] ?? ''),
                            ':mobile'     => $this->sanitize($row['mobile'] ?? ''),
                            ':job_title'  => $this->sanitize($row['job_title'] ?? ''),
                            ':department' => $this->sanitize($row['department'] ?? ''),
                            ':linkedin'   => $this->sanitize($row['linkedin'] ?? ''),
                            ':country'    => $this->sanitize($row['country'] ?? ''),
                            ':city'       => $this->sanitize($row['city'] ?? ''),
                            ':postal_code'=> $this->sanitize($row['postal_code'] ?? ''),
                            ':address'    => $this->sanitize($row['address'] ?? ''),
                        ]);
                        $inserted++;
                    } catch (\Exception $e) {
                        $skipped++;
                        $errors[] = "Fila " . ($i + 2) . ": " . $e->getMessage();
                    }
                }

            } else { // accounts
                $sql = "INSERT INTO accounts
                    (tenant_id, owner_id, name, type, priority, industry, website, linkedin,
                     phone, email, country, city, postal_code, billing_address, notes, created_at)
                    VALUES
                    (:tenant_id, :owner_id, :name, :type, :priority, :industry, :website, :linkedin,
                     :phone, :email, :country, :city, :postal_code, :billing_address, :notes, NOW())
                    ON DUPLICATE KEY UPDATE updated_at = NOW()";

                $stmt = $db->prepare($sql);

                foreach ($rows as $i => $row) {
                    $name = trim($row['name'] ?? '');
                    if ($name === '') { $skipped++; continue; }

                    try {
                        $stmt->execute([
                            ':tenant_id'       => $tenantId,
                            ':owner_id'        => $ownerId,
                            ':name'            => $this->sanitize($name),
                            ':type'            => $this->sanitize($row['type'] ?? 'customer'),
                            ':priority'        => $this->sanitize($row['priority'] ?? 'B'),
                            ':industry'        => $this->sanitize($row['industry'] ?? ''),
                            ':website'         => $this->sanitize($row['website'] ?? ''),
                            ':linkedin'        => $this->sanitize($row['linkedin'] ?? ''),
                            ':phone'           => $this->sanitize($row['phone'] ?? ''),
                            ':email'           => $this->sanitize($row['email'] ?? ''),
                            ':country'         => $this->sanitize($row['country'] ?? ''),
                            ':city'            => $this->sanitize($row['city'] ?? ''),
                            ':postal_code'     => $this->sanitize($row['postal_code'] ?? ''),
                            ':billing_address' => $this->sanitize($row['billing_address'] ?? ''),
                            ':notes'           => $this->sanitize($row['notes'] ?? ''),
                        ]);
                        $inserted++;
                    } catch (\Exception $e) {
                        $skipped++;
                        $errors[] = "Fila " . ($i + 2) . ": " . $e->getMessage();
                    }
                }
            }

            $db->commit();

            $this->auditLog->log(
                'create',
                "import_{$type}",
                0,
                null,
                ['inserted' => $inserted, 'skipped' => $skipped]
            );

            unset($_SESSION['import_pending']);

            echo json_encode([
                'success'  => true,
                'inserted' => $inserted,
                'skipped'  => $skipped,
                'errors'   => array_slice($errors, 0, 20),
            ]);

        } catch (\Exception $e) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => 'Error en la transacción: ' . $e->getMessage()]);
        }
        exit;
    }

    // ──────────────────────────────────────────────────────────
    //  GET /importar/plantilla  — descarga plantilla CSV
    // ──────────────────────────────────────────────────────────
    public function template(): void
    {
        Permission::require('contacts', 'create');

        $type = $_GET['type'] ?? 'contacts';

        if ($type === 'contacts') {
            $filename = 'plantilla_contactos.csv';
            $headers  = ['first_name','last_name','type','email','phone','mobile',
                         'job_title','department','linkedin','country','city','postal_code','address'];
            $sample   = [
                ['Juan','García','Cliente','juan@empresa.com','55-1234-5678','55-8765-4321',
                 'Gerente','Ventas','https://linkedin.com/in/juangarcia','México','CDMX','06600','Av. Principal 100'],
                ['María','López','Prospecto','maria@corp.mx','55-0000-1111','',
                 'Directora','Marketing','','México','Guadalajara','44100',''],
            ];
        } else {
            $filename = 'plantilla_organizaciones.csv';
            $headers  = ['name','type','priority','industry','website','linkedin',
                         'phone','email','country','city','postal_code','billing_address','notes'];
            $sample   = [
                ['Empresa Ejemplo S.A.','customer','A','Tecnología','https://empresa.com',
                 'https://linkedin.com/company/ejemplo','55-1234-0000','info@empresa.com',
                 'México','CDMX','06600','Av. Reforma 500, Piso 10','Cliente frecuente'],
                ['Distribuciones XYZ','partner','B','Logística','',
                 '','55-9876-0000','ventas@xyz.mx',
                 'México','Monterrey','64000','',''],
            ];
        }

        header('Content-Type: text/csv; charset=UTF-8');
        header("Content-Disposition: attachment; filename=\"{$filename}\"");
        header('Cache-Control: no-cache, no-store, must-revalidate');

        // BOM for Excel UTF-8 compatibility
        echo "\xEF\xBB\xBF";

        $out = fopen('php://output', 'w');
        fputcsv($out, $headers);
        foreach ($sample as $row) {
            fputcsv($out, $row);
        }
        fclose($out);
        exit;
    }

    // ──────────────────────────────────────────────────────────
    //  Helpers
    // ──────────────────────────────────────────────────────────
    private function parseCsv(string $path): array
    {
        $handle = fopen($path, 'r');
        if (!$handle) throw new \RuntimeException('No se pudo abrir el archivo.');

        // Strip BOM
        $bom = fread($handle, 3);
        if ($bom !== "\xEF\xBB\xBF") rewind($handle);

        $headers = null;
        $rows    = [];

        while (($line = fgetcsv($handle, 4096, ',')) !== false) {
            // Try semicolon if single column
            if (count($line) === 1 && strpos($line[0], ';') !== false) {
                $line = str_getcsv($line[0], ';');
            }

            if ($headers === null) {
                $headers = array_map(fn($h) => strtolower(trim(str_replace(' ', '_', $h))), $line);
                continue;
            }

            $row = [];
            foreach ($headers as $i => $h) {
                $row[$h] = trim($line[$i] ?? '');
            }

            // Skip fully empty rows
            if (array_filter($row, fn($v) => $v !== '') === []) continue;

            $rows[] = $row;
        }

        fclose($handle);
        return $rows;
    }

    private function sanitize(string $value): ?string
    {
        $v = trim(strip_tags($value));
        return $v === '' ? null : mb_substr($v, 0, 500);
    }
}
