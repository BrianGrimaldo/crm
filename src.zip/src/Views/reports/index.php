<?php
$pageTitle = 'Reportes - Einsur Global CRM';
require __DIR__ . '/../layouts/header.php';

$activeTab = $_GET['tab'] ?? 'general';
$selectedSellerId = isset($_GET['seller_id']) && $_GET['seller_id'] !== '' ? (int)$_GET['seller_id'] : null;
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
?>

<style>
    .tabs-container {
        display: flex;
        gap: 1.5rem;
        border-bottom: 2px solid var(--border);
        margin-bottom: 2.5rem;
        padding-bottom: 0.2rem;
    }
    .tab-btn {
        padding: 0.75rem 1.25rem;
        font-size: 1.05rem;
        font-weight: 600;
        text-decoration: none;
        color: var(--text-muted);
        position: relative;
        transition: all 0.3s ease;
    }
    .tab-btn:hover {
        color: var(--primary);
    }
    .tab-btn.active {
        color: var(--primary);
    }
    .tab-btn.active::after {
        content: '';
        position: absolute;
        bottom: -4px;
        left: 0;
        width: 100%;
        height: 3px;
        background: var(--primary);
        border-radius: 3px;
    }
    
    .filter-card {
        background: var(--surface);
        border-radius: var(--radius-lg);
        padding: 2rem;
        box-shadow: var(--shadow-md);
        border: 1px solid rgba(0,0,0,0.03);
        margin-bottom: 2rem;
    }

    .report-table-card {
        background: var(--surface);
        border-radius: var(--radius-lg);
        padding: 2rem;
        box-shadow: var(--shadow-md);
        border: 1px solid rgba(0,0,0,0.03);
    }

    .badge {
        display: inline-flex;
        align-items: center;
        padding: 0.25rem 0.6rem;
        border-radius: 6px;
        font-size: 0.8rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .badge-active {
        background: rgba(16, 185, 129, 0.1);
        color: #10b981;
    }
    .badge-won {
        background: rgba(16, 185, 129, 0.15);
        color: #10b981;
    }
    .badge-lost {
        background: rgba(239, 68, 68, 0.15);
        color: #ef4444;
    }
    .badge-open {
        background: rgba(99, 102, 241, 0.15);
        color: #6366f1;
    }
</style>

<div class="page-header">
    <div>
        <h1>Reportes y Exportación</h1>
        <p>Genera reportes de ventas y analiza la línea de tiempo de tus vendedores.</p>
    </div>
</div>

<div class="tabs-container">
    <a href="?tab=general" class="tab-btn <?= $activeTab === 'general' ? 'active' : '' ?>">
        <i class="fas fa-file-invoice-dollar" style="margin-right: 0.5rem;"></i> Ventas Generales
    </a>
    <a href="?tab=timeline" class="tab-btn <?= $activeTab === 'timeline' ? 'active' : '' ?>">
        <i class="fas fa-history" style="margin-right: 0.5rem;"></i> Línea de Tiempo de Vendedores
    </a>
</div>

<?php if ($activeTab === 'general'): ?>
    <!-- TAB 1: VENTAS GENERALES -->
    <div class="filter-card" style="max-width: 800px;">
        <h3 style="margin-bottom: 1.5rem; border-bottom: 1px solid var(--border); padding-bottom: 0.5rem; color: var(--primary);">
            Exportar Oportunidades de Venta
        </h3>
        
        <form action="/reportes/exportar-ventas" method="GET">
            <input type="hidden" name="tab" value="general">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="start_date">Fecha de Inicio</label>
                    <input type="date" id="start_date" name="start_date" class="form-control" value="<?= htmlspecialchars($startDate) ?>">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="end_date">Fecha de Fin</label>
                    <input type="date" id="end_date" name="end_date" class="form-control" value="<?= htmlspecialchars($endDate) ?>">
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 2rem;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="seller_id">Filtrar por Vendedor</label>
                    <select id="seller_id" name="seller_id" class="form-control">
                        <option value="">Todos los vendedores</option>
                        <?php foreach ($vendedores as $vendedor): ?>
                            <option value="<?= $vendedor->id ?>" <?= $selectedSellerId === $vendedor->id ? 'selected' : '' ?>>
                                 <?= htmlspecialchars($vendedor->first_name . ' ' . $vendedor->last_name) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="status">Estado del Trato</label>
                    <select id="status" name="status" class="form-control">
                        <option value="all">Cualquier estado</option>
                        <option value="open">Solo Abiertos</option>
                        <option value="won">Solo Ganados</option>
                        <option value="lost">Solo Perdidos</option>
                    </select>
                </div>
            </div>

            <div style="text-align: right;">
                <button type="submit" class="btn btn-primary" style="padding: 0.85rem 2rem;">
                    <i class="fas fa-file-excel"></i> Descargar Reporte (Excel)
                </button>
            </div>
        </form>
    </div>

<?php elseif ($activeTab === 'timeline'): ?>
    <!-- TAB 2: LÍNEA DE TIEMPO DE VENDEDORES -->
    <div class="filter-card">
        <h3 style="margin-bottom: 1.5rem; border-bottom: 1px solid var(--border); padding-bottom: 0.5rem; color: var(--primary);">
            Filtrar Tiempos por Etapa
        </h3>
        
        <form action="/reportes" method="GET">
            <input type="hidden" name="tab" value="timeline">
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; margin-bottom: 1.5rem;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="start_date">Fecha de Inicio</label>
                    <input type="date" id="start_date" name="start_date" class="form-control" value="<?= htmlspecialchars($startDate) ?>">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="end_date">Fecha de Fin</label>
                    <input type="date" id="end_date" name="end_date" class="form-control" value="<?= htmlspecialchars($endDate) ?>">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="seller_id">Filtrar por Vendedor</label>
                    <select id="seller_id" name="seller_id" class="form-control">
                        <option value="">Todos los vendedores</option>
                        <?php foreach ($vendedores as $vendedor): ?>
                            <option value="<?= $vendedor->id ?>" <?= $selectedSellerId === $vendedor->id ? 'selected' : '' ?>>
                                 <?= htmlspecialchars($vendedor->first_name . ' ' . $vendedor->last_name) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 2rem;">
                <button type="submit" class="btn" style="background: var(--bg-main); color: var(--text-main); border: 1px solid var(--border);">
                    <i class="fas fa-search"></i> Consultar en Pantalla
                </button>
                
                <a href="/reportes/exportar-timeline?tab=timeline&start_date=<?= urlencode($startDate) ?>&end_date=<?= urlencode($endDate) ?>&seller_id=<?= $selectedSellerId ?>" class="btn btn-primary">
                    <i class="fas fa-file-excel"></i> Descargar Reporte (Excel)
                </a>
            </div>
        </form>
    </div>

    <!-- Resultados en Pantalla -->
    <div class="report-table-card">
        <h3 style="margin-bottom: 1.5rem; color: var(--primary);">Línea de Tiempo del Embudo</h3>
        
        <div class="table-responsive">
            <table style="width: 100%;">
                <thead>
                    <tr>
                        <th>Oportunidad (Trato)</th>
                        <th>Vendedor</th>
                        <th>Etapa</th>
                        <th>Fecha Entrada</th>
                        <th>Fecha Salida</th>
                        <th>Tiempo en Etapa</th>
                        <th>Monto</th>
                        <th>Estado Actual</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($timeline)): ?>
                        <tr>
                            <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 3rem 1rem;">
                                <i class="fas fa-history" style="font-size: 2rem; margin-bottom: 0.5rem; color: #cbd5e1;"></i><br>
                                No se encontraron registros de tiempos para los filtros seleccionados.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($timeline as $row): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($row['deal_name']) ?></strong></td>
                                <td><?= htmlspecialchars($row['seller_name']) ?></td>
                                <td>
                                    <span style="font-weight: 600; color: var(--primary);">
                                        <?= htmlspecialchars($row['stage_name']) ?>
                                    </span>
                                </td>
                                <td style="font-size: 0.85rem; color: var(--text-muted);">
                                    <?= date('d/m/Y H:i', strtotime($row['entered_at'])) ?>
                                </td>
                                <td style="font-size: 0.85rem; color: var(--text-muted);">
                                    <?php if ($row['exited_at']): ?>
                                        <?= date('d/m/Y H:i', strtotime($row['exited_at'])) ?>
                                    <?php else: ?>
                                        <span class="badge badge-active">Activo</span>
                                    <?php endif; ?>
                                </td>
                                <td style="font-weight: 700; color: var(--primary);">
                                    <?= htmlspecialchars($this->formatDuration((int)$row['duration'])) ?>
                                </td>
                                <td style="font-weight: bold; color: #059669;">
                                    $<?= number_format((float)$row['amount'], 2) ?> <?= htmlspecialchars($row['currency_code']) ?>
                                </td>
                                <td>
                                    <?php if ($row['status'] === 'Ganado'): ?>
                                        <span class="badge badge-won">Ganado</span>
                                    <?php elseif ($row['status'] === 'Perdido'): ?>
                                        <span class="badge badge-lost">Perdido</span>
                                    <?php else: ?>
                                        <span class="badge badge-open">Abierto</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
